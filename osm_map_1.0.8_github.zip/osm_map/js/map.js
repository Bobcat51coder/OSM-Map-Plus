/**
 * OSM Map Enhanced for Piwigo - map.js v2.1.0
 */
'use strict';

var OSMMap = (function () {


  var map, clusterGroup;
  var allPhotos     = [];
  var visiblePhotos = [];
  var inViewPhotos  = [];
  var geocodeTimer  = null;
  var panelOpen     = false;
  var apiUrl        = '';

  // ── Fonds de carte ─────────────────────────────────────────────────────
  // Depuis le 26/08/2026, les tuiles CartoDB nécessitent une clé API gratuite
  // (https://carto.com/basemaps/apikey/), injectée côté PHP dans window.OSM_CARTO_API_KEY
  var _cartoKey = window.OSM_CARTO_API_KEY || '';
  var _cartoSuffix = _cartoKey ? ('?key=' + encodeURIComponent(_cartoKey)) : '';
  var TILES = {
    carto_voyager: {
      url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png' + _cartoSuffix,
      attr: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; CARTO',
      maxZoom: 19
    },
    osm_standard: {
      url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      attr: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19
    },
    esri_satellite: {
      url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      attr: 'Tiles &copy; Esri &mdash; Source: Esri, USGS, NOAA',
      maxZoom: 18
    },
    opentopo: {
      url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
      attr: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://opentopomap.org/">OpenTopoMap</a>',
      maxZoom: 17
    },
    osm_france: {
      url: 'https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png',
      attr: '&copy; <a href="https://www.openstreetmap.fr/">OpenStreetMap France</a> | &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 20
    },
    // Fonds vectoriels (MapLibre GL, chargé à la demande)
    openfreemap: {
      vector: true,
      style: 'https://tiles.openfreemap.org/styles/liberty',
      attr: '<a href="https://openfreemap.org" target="_blank" rel="noopener">OpenFreeMap</a> &copy; <a href="https://www.openmaptiles.org/" target="_blank" rel="noopener">OpenMapTiles</a> Data from <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>'
    },
    sat_labels: {
      vector: true,
      style: null,   // construit par _satLabelsStyle()
      attr: 'Imagery &copy; Esri, Maxar, Earthstar Geographics &mdash; Noms : <a href="https://openfreemap.org" target="_blank" rel="noopener">OpenFreeMap</a> &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>'
    }
  };

  // Libellés du sélecteur de fond de carte (ordre d'affichage)
  var BASEMAP_CHOICES = [
    ['carto_voyager', 'Carto Voyager'],
    ['osm_standard',  'OpenStreetMap'],
    ['osm_france',    'OpenStreetMap France'],
    ['openfreemap',   'OpenFreeMap'],
    ['esri_satellite','Satellite (Esri)'],
    ['sat_labels',    'Satellite + noms'],
    ['opentopo',      'Topographique']
  ];
  var MAPLIBRE_JS  = 'https://cdn.jsdelivr.net/npm/maplibre-gl@4.7.1/dist/maplibre-gl.js';
  var MAPLIBRE_CSS = 'https://cdn.jsdelivr.net/npm/maplibre-gl@4.7.1/dist/maplibre-gl.css';
  var MLLEAFLET_JS = 'https://cdn.jsdelivr.net/npm/@maplibre/maplibre-gl-leaflet@0.0.22/leaflet-maplibre-gl.js';
  var baseLayer = null, baseKey = null, baseToken = 0, defaultBaseKey = 'carto_voyager';

  // Attend que Leaflet (+ MarkerCluster) soit disponible : réutilise celui d'un autre plugin s'il est déjà là
  function init(options) {
    (window.osmmeLeaflet || function (n, cb) { cb(); })(true, function () { _init(options); });
  }

  function _init(options) {
    apiUrl   = options.apiUrl || window.OSM_API_URL || 'ws.php';
    var initZoom = options.initZoom || 5;

    // Initialiser la carte immédiatement (vue monde) sans attendre les données
    try {
      _initMap(options.mapHeight || 500, initZoom, options.tile || 'carto_voyager', null);
    } catch (e) {
      console.error('OSM Map: initialisation de la carte', e);
    }
    if (!map) return;
    _bindControls();

    // Charger les points GPS via l'endpoint léger (lat/lng/id uniquement)
    var pointsUrl = window.OSM_POINTS_URL || options.pointsUrl;
    if (pointsUrl) {
      _showLoading(true);
      fetch(pointsUrl, { credentials: 'same-origin' })
        .then(function(r) {
          if (!r.ok) throw new Error('HTTP ' + r.status);
          return r.text();
        })
        .then(function(text) {
          // Vérifier que la réponse est bien du JSON avant de parser
          var trimmed = text.trim();
          if (!trimmed || trimmed[0] !== '[') {
            throw new Error('Réponse non-JSON : ' + trimmed.substring(0, 100));
          }
          return JSON.parse(trimmed);
        })
        .then(function(data) {
          // Format compact : [[id, lat, lng], ...]
          allPhotos = data.map(function(p) {
            return { id: p[0], latitude: p[1], longitude: p[2] };
          });
          visiblePhotos = allPhotos.slice();
          // Recentrer sur les données réelles
          var bounds = _computeBounds(allPhotos);
          if (bounds) {
            try {
              var b = L.latLngBounds(bounds[0], bounds[1]);
              if (b.isValid()) map.fitBounds(b.pad(0.05));
            } catch(e) {}
          }
          // Désactiver moveend pendant le rendu initial pour éviter les conflits
          map.off('moveend zoomend', _updatePanelFromBounds);
          _renderMarkers(allPhotos);
          // Réactiver après un délai suffisant pour laisser les chunks se charger
          setTimeout(function() {
            // Le panneau suit désormais la zone visible (zoom / déplacement)
            map.off('moveend zoomend', _updatePanelFromBounds);
            map.on('moveend zoomend', _updatePanelFromBounds);
            _updatePanelFromBounds();
          }, 200);
          _showLoading(false);
        })
        .catch(function(err) {
          console.error('OSM Map: erreur chargement points', err);
          _showLoading(false);
        });
    } else {
      // Fallback : données inline (page galerie)
      allPhotos     = options.photos || window.OSM_ALL_PHOTOS || [];
      visiblePhotos = allPhotos.slice();
      var initialBounds = _computeBounds(allPhotos);
      if (initialBounds && map) {
        try {
          var b = L.latLngBounds(initialBounds[0], initialBounds[1]);
          if (b.isValid()) map.fitBounds(b.pad(0.05));
        } catch(e) {}
      }
      map.off('moveend zoomend', _updatePanelFromBounds);
      _renderMarkers(allPhotos);
      setTimeout(function() {
        map.on('moveend zoomend', _updatePanelFromBounds);
        _updatePanelFromBounds();
      }, 200);
    }
  }

  function _showLoading(show) {
    var el = document.getElementById('osm-loading');
    if (el) el.style.display = show ? 'inline' : 'none';
    var cnt = document.getElementById('osm-count-visible');
    if (cnt && show) cnt.textContent = '…';
  }

  // Calcule le LatLngBounds de toutes les photos passées en paramètre
  function _computeBounds(photos) {
    if (!photos || !photos.length) return null;
    var lats = photos.map(function(p){ return p.latitude; });
    var lngs = photos.map(function(p){ return p.longitude; });
    var minLat = Math.min.apply(null, lats);
    var maxLat = Math.max.apply(null, lats);
    var minLng = Math.min.apply(null, lngs);
    var maxLng = Math.max.apply(null, lngs);
    return [[minLat, minLng], [maxLat, maxLng]];
  }

  function _initMap(height, initZoom, tileKey, initialBounds) {
    var container = document.getElementById('osm-map');
    if (!container || typeof L === 'undefined') return;
    container.style.height = height + 'px';
    // Contraindre le panel et son body à la même hauteur que la carte
    var panel = document.getElementById('osm-panel');
    if (panel) panel.style.maxHeight = height + 'px';
    var body = container.parentNode;
    if (body && body.classList && body.classList.contains('osm-body')) {
      body.style.height = height + 'px';
    }

    // Forcer la hauteur du container parent = carte + header + footer
    // Neutralise toute règle CSS externe (thème, osm-map-wrapper, etc.)
    var wrapper = container.closest
      ? container.closest('#osm-map-container')
      : document.getElementById('osm-map-container');
    if (wrapper) {
      wrapper.style.height    = '';      // reset toute hauteur CSS forcée
      wrapper.style.minHeight = '';
      wrapper.style.maxHeight = '';
      // Laisser le navigateur recalculer après reset
      requestAnimationFrame(function() {
        wrapper.style.height = '';
      });
    }

    // Si on a des données, utiliser fitBounds au lieu d'un centre fixe
    var mapOptions;
    if (initialBounds) {
      // Initialiser sans centre/zoom : on fera fitBounds juste après
      mapOptions = { center: [0, 0], zoom: 2 };
    } else {
      mapOptions = { center: [46.5, 2.5], zoom: initZoom };
    }

    // maxZoom explicite : un fond vectoriel (chargé en différé) n'a pas encore de couche à cet instant,
    // et Leaflet.markercluster / fitBounds exigent un zoom maximum connu (sinon l'init plante)
    mapOptions.maxZoom = 19;
    map = L.map('osm-map', mapOptions);
    // La molette ne zoome la carte qu'après un clic dans la carte (sinon elle défile la page)
    map.scrollWheelZoom.disable();
    map.on('click focus', function () { map.scrollWheelZoom.enable(); });
    map.on('mouseout', function () { map.scrollWheelZoom.disable(); });
    var startKey = TILES[tileKey] ? tileKey : 'carto_voyager';
    defaultBaseKey = startKey;
    try {
      var saved = JSON.parse(window.localStorage.getItem('osmme_basemap') || 'null');
      if (saved && saved.d === startKey && TILES[saved.k]) startKey = saved.k;   // valable tant que le défaut admin n'a pas changé
    } catch (e) {}
    _setBasemap(startKey);
    _buildBasemapControl(startKey);

    // Ajuster la vue sur les données réelles dès le départ
    if (initialBounds) {
      try {
        var b = L.latLngBounds(initialBounds[0], initialBounds[1]);
        if (b.isValid()) map.fitBounds(b.pad(0.1));
      } catch(e) {
        map.setView([46.5, 2.5], initZoom);
      }
    }

    if (!L.markerClusterGroup) {
      console.warn('OSM Map: Leaflet.markercluster indisponible, affichage sans regroupement');
      clusterGroup = L.featureGroup();
      clusterGroup.addLayers = function (arr) { var g = this; arr.forEach(function (m) { g.addLayer(m); }); };
    } else clusterGroup = L.markerClusterGroup({
      iconCreateFunction: function (cluster) {
        return thumbsMode ? _thumbClusterIcon(cluster)
                          : L.MarkerClusterGroup.prototype._defaultIconCreateFunction.call(this, cluster);
      },
      chunkedLoading: true,
      chunkSize: 500,           // chunks plus grands = moins de passes RAF
      chunkDelay: 10,           // délai minimal entre chunks
      maxClusterRadius: 80,     // agrégation plus agressive = moins de marqueurs DOM
      showCoverageOnHover: false,
      animate: false,           // désactiver les animations = bien plus rapide avec 15k+ points
      animateAddingMarkers: false,
      removeOutsideVisibleBounds: true  // ne rend que les marqueurs visibles
    });
    map.addLayer(clusterGroup);

    // moveend est activé après le chargement des données (voir init)
    window.addEventListener('resize', function () { map.invalidateSize(); });
    // Taille réelle du conteneur : recalcul si elle change après l'init (thème, chargement tardif…)
    if (window.ResizeObserver) { new ResizeObserver(function () { map.invalidateSize(); }).observe(container); }
    [200, 800, 2000].forEach(function (t) { setTimeout(function () { map.invalidateSize(); }, t); });
    // Le fond vectoriel (MapLibre) est repositionné à chaque déplacement / redimensionnement
    function syncBase() { if (baseLayer && baseLayer._update && baseKey && TILES[baseKey] && TILES[baseKey].vector) { try { baseLayer._update(); } catch (e) {} } }
    map.on('moveend zoomend resize', syncBase);
    map.on('moveend zoomend', function () { if (thumbsMode) { _scanTries = 0; clearTimeout(_scanTimer); _scanTimer = setTimeout(_scanThumbs, 350); } });
  }

  // ── Gestion des fonds de carte ────────────────────────────────────────────
  function _loadScript(src, cb, errCb) {
    var el = document.createElement('script');
    el.src = src; el.async = true;
    el.onload = cb; el.onerror = errCb;
    document.head.appendChild(el);
  }
  function _loadCss(href) {
    if (document.querySelector('link[href="' + href + '"]')) return;
    var l = document.createElement('link');
    l.rel = 'stylesheet'; l.href = href;
    document.head.appendChild(l);
  }
  // Charge MapLibre GL + le plugin Leaflet une seule fois
  function _withMapLibre(ok, fail) {
    if (window.maplibregl && L.maplibreGL) { ok(); return; }
    _loadCss(MAPLIBRE_CSS);
    function step2() {
      if (L.maplibreGL) { ok(); return; }
      _loadScript(MLLEAFLET_JS, ok, fail);
    }
    if (window.maplibregl) { step2(); return; }
    _loadScript(MAPLIBRE_JS, step2, fail);
  }

  // Style « satellite + noms » : imagerie Esri + noms de lieux/routes OpenFreeMap (en français si dispo)
  function _satLabelsStyle() {
    var name = ['coalesce', ['get', 'name:fr'], ['get', 'name']];
    var font = ['Noto Sans Regular'];
    var fontB = ['Noto Sans Bold'];
    var halo = { 'text-color': '#ffffff', 'text-halo-color': 'rgba(0,0,0,0.75)', 'text-halo-width': 1.5 };
    function place(id, classes, minzoom, size, bold) {
      return {
        id: id, type: 'symbol', source: 'ofm', 'source-layer': 'place', minzoom: minzoom,
        filter: ['match', ['get', 'class'], classes, true, false],
        layout: { 'text-field': name, 'text-font': bold ? fontB : font, 'text-size': size, 'text-max-width': 8 },
        paint: halo
      };
    }
    return {
      version: 8,
      glyphs: 'https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf',
      sources: {
        esri: { type: 'raster', tileSize: 256, maxzoom: 19,
                tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'] },
        ofm:  { type: 'vector', url: 'https://tiles.openfreemap.org/planet' }
      },
      layers: [
        { id: 'esri', type: 'raster', source: 'esri' },
        place('pl-country', ['country'], 1, ['interpolate', ['linear'], ['zoom'], 1, 11, 6, 16], true),
        place('pl-state',   ['state', 'province'], 4, 13, false),
        place('pl-city',    ['city', 'town'], 5, ['interpolate', ['linear'], ['zoom'], 5, 12, 12, 19], true),
        place('pl-village', ['village', 'suburb', 'quarter', 'neighbourhood'], 10, ['interpolate', ['linear'], ['zoom'], 10, 11, 15, 15], false),
        place('pl-hamlet',  ['hamlet', 'isolated_dwelling'], 12, 11, false),
        { id: 'roads', type: 'symbol', source: 'ofm', 'source-layer': 'transportation_name', minzoom: 12,
          layout: { 'text-field': name, 'text-font': font, 'text-size': 11, 'symbol-placement': 'line' }, paint: halo },
        { id: 'water', type: 'symbol', source: 'ofm', 'source-layer': 'water_name', minzoom: 3,
          layout: { 'text-field': name, 'text-font': font, 'text-size': 12 },
          paint: { 'text-color': '#cfe8ff', 'text-halo-color': 'rgba(0,0,0,0.75)', 'text-halo-width': 1.5 } }
      ]
    };
  }

  function _setBasemap(key) {
    if (!map) return;
    var t = TILES[key] || TILES['carto_voyager'];
    if (!TILES[key]) key = 'carto_voyager';
    var token = ++baseToken;

    function apply(layer) {
      if (token !== baseToken) return;          // un choix plus récent a pris le relais
      if (baseLayer) { try { map.removeLayer(baseLayer); } catch (e) {} }
      baseLayer = layer;
      baseKey = key;
      layer.addTo(map);
      if (layer.bringToBack) layer.bringToBack();
      var sel = document.getElementById('osm-basemap');
      if (sel) sel.value = key;
      try { window.localStorage.setItem('osmme_basemap', JSON.stringify({ d: defaultBaseKey, k: key })); } catch (e) {}
    }

    if (!t.vector) {
      apply(L.tileLayer(t.url, { attribution: t.attr, maxZoom: t.maxZoom }));
      return;
    }
    // Fonds vectoriels : nécessitent WebGL ; sinon retour au fond précédent
    var fail = function () {
      if (token !== baseToken) return;
      _showToast('Ce fond de carte n\u2019a pas pu \u00eatre charg\u00e9 (WebGL requis).', 'info');
      var sel = document.getElementById('osm-basemap');
      if (sel && baseKey) sel.value = baseKey;
    };
    _withMapLibre(function () {
      if (token !== baseToken) return;
      try {
        apply(L.maplibreGL({
          style: key === 'sat_labels' ? _satLabelsStyle() : t.style,
          attribution: t.attr
        }));
      } catch (e) { console.error('OSM Map: fond vectoriel', e); fail(); }
    }, fail);
  }

  function _buildBasemapControl(currentKey) {
    if (document.getElementById('osm-basemap')) return;
    var anchor = document.getElementById('osm-btn-fit') || document.getElementById('osm-btn-panel');
    if (!anchor || !anchor.parentNode) return;

    var wrap = document.createElement('span');
    wrap.className = 'osm-control-group osm-basemap-group';
    var label = document.createElement('label');
    label.setAttribute('for', 'osm-basemap');
    label.textContent = 'Fond';
    var sel = document.createElement('select');
    sel.id = 'osm-basemap';
    BASEMAP_CHOICES.forEach(function (c) {
      var o = document.createElement('option');
      o.value = c[0]; o.textContent = c[1];
      sel.appendChild(o);
    });
    sel.value = currentKey;
    sel.addEventListener('change', function () { _setBasemap(this.value); });

    var btn3d = document.createElement('button');
    btn3d.id = 'osm-btn-3d';
    btn3d.type = 'button';
    btn3d.title = 'Ouvrir la carte en relief 3D dans un nouvel onglet';
    btn3d.innerHTML = '&#127956;&#65039; 3D';
    btn3d.addEventListener('click', _open3D);

    var btnTh = document.createElement('button');
    btnTh.id = 'osm-btn-thumbs';
    btnTh.type = 'button';
    btnTh.title = 'Afficher les groupes de photos sous forme de vignettes';
    btnTh.innerHTML = '&#128444;&#65039; Vignettes';
    btnTh.addEventListener('click', _toggleThumbs);

    wrap.appendChild(label); wrap.appendChild(sel); wrap.appendChild(btn3d);
    if (L.markerClusterGroup) { wrap.appendChild(btnTh); setTimeout(_syncThumbsButton, 0); }
    anchor.parentNode.insertBefore(wrap, anchor);
  }

  // Album filtré en cours (liste déroulante, ou page d'album via OSM_POINTS_URL)
  function _currentCat() {
    var sel = document.getElementById('osm-album-filter');
    var cat = sel ? parseInt(sel.value, 10) : 0;
    if (!cat) {
      var m = /[?&]cat_id=(\d+)/.exec(window.OSM_POINTS_URL || '');
      if (m) cat = parseInt(m[1], 10);
    }
    return cat || 0;
  }

  // Diaporama (nouvel onglet) des photos de la zone visible, par date croissante
  function _openSlideshow() {
    if (!map) return;
    var b = map.getBounds();
    var url = (window.OSM_ROOT || '') + 'plugins/osm_map/osmme-slideshow.php'
            + '?s=' + b.getSouth().toFixed(5) + '&n=' + b.getNorth().toFixed(5)
            + '&w=' + b.getWest().toFixed(5) + '&e=' + b.getEast().toFixed(5);
    var cat = _currentCat();
    if (cat) url += '&cat_id=' + cat;
    var ord = document.getElementById('osm-slideshow-order');
    if (ord) { url += '&order=' + ord.value; try { window.localStorage.setItem('osmme_slideshow_order', ord.value); } catch (e) {} }
    window.open(url, '_blank', 'noopener');
  }
  function _addSlideshowButton() {
    if (document.getElementById('osm-btn-slideshow')) return;
    var closeEl = document.getElementById('osm-panel-close');
    var head = document.querySelector('#osm-panel .osm-panel-header') || (closeEl && closeEl.parentNode);
    if (!head) return;
    var btn = document.createElement('button');
    btn.id = 'osm-btn-slideshow';
    btn.type = 'button';
    btn.title = 'Lancer un diaporama des photos de la zone visible (nouvel onglet)';
    btn.innerHTML = '&#9654; Diaporama';
    btn.addEventListener('click', _openSlideshow);
    var ord = document.createElement('select');
    ord.id = 'osm-slideshow-order';
    ord.title = 'Ordre du diaporama';
    [['asc', 'Date \u2191'], ['desc', 'Date \u2193'], ['rand', 'Al\u00e9atoire']].forEach(function (o) {
      var op = document.createElement('option'); op.value = o[0]; op.textContent = o[1]; ord.appendChild(op);
    });
    try { var sv = window.localStorage.getItem('osmme_slideshow_order'); if (sv) ord.value = sv; } catch (e) {}
    var close = document.getElementById('osm-panel-close');
    if (close && close.parentNode === head) { head.insertBefore(ord, close); head.insertBefore(btn, close); }
    else { head.appendChild(ord); head.appendChild(btn); }
  }

  // Ouvre la vue 3D sur la zone courante, avec le filtre album en cours
  function _open3D() {
    if (!map) return;
    var c = map.getCenter();
    var url = (window.OSM_ROOT || '') + 'plugins/osm_map/osmme-3d.php'
            + '?lat=' + c.lat.toFixed(5) + '&lng=' + c.lng.toFixed(5)
            + '&z=' + map.getZoom()
            + '&base=' + (baseKey === 'sat_labels' || baseKey === 'esri_satellite' ? 'sat' : (baseKey === 'osm_france' ? 'osmfr' : 'ofm'));
    var sel = document.getElementById('osm-album-filter');
    var cat = sel ? parseInt(sel.value, 10) : 0;
    if (!cat) {
      // Page d'album : le filtre est dans OSM_POINTS_URL (?cat_id=)
      var m = /[?&]cat_id=(\d+)/.exec(window.OSM_POINTS_URL || '');
      if (m) cat = parseInt(m[1], 10);
    }
    if (cat) url += '&cat_id=' + cat;
    window.open(url, '_blank', 'noopener');
  }

  // Token pour annuler un rendu en cours si un nouveau démarre (filtre album)
  var _renderToken = 0;

  // ── Mode « Vignettes » : groupes et photos isolées affichés sous forme de miniatures ──
  var thumbsMode = false;
  try { thumbsMode = window.localStorage.getItem('osmme_thumbs') === '1'; } catch (e) {}
  var _thumbCache = {}, _thumbWanted = {}, _thumbAsked = {}, _thumbTimer = null, _lastPhotos = null;

  function _cssUrl(u) { return String(u).replace(/"/g, '%22').replace(/'/g, '%27').replace(/\(/g, '%28').replace(/\)/g, '%29'); }
  function _applyThumb(id) {
    var u = _thumbCache[id];
    if (!u) return;
    var els = document.querySelectorAll('.osm-thumb-img[data-pid="' + id + '"]');
    for (var i = 0; i < els.length; i++) { els[i].style.backgroundImage = 'url("' + _cssUrl(u) + '")'; els[i].setAttribute('data-ok', '1'); }
  }
  function _flushThumbs() {
    _thumbTimer = null;
    var all = Object.keys(_thumbWanted).filter(function (id) { return !_thumbCache[id] && !_thumbAsked[id]; });
    var ids = all.slice(0, 100);
    _thumbWanted = {};
    all.slice(100).forEach(function (id) { _thumbWanted[id] = 1; });      // le reste part au lot suivant
    if (all.length > 100) _thumbTimer = setTimeout(_flushThumbs, 60);
    if (!ids.length || !window.OSM_PHOTO_URL) return;
    ids.forEach(function (id) { _thumbAsked[id] = 1; });
    fetch(window.OSM_PHOTO_URL + '?ids=' + ids.join(','), { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (list) {
        var got = {};
        (list || []).forEach(function (d) { if (d && d.thumbnail_url) { got[d.id] = 1; _thumbCache[d.id] = d.thumbnail_url; _applyThumb(d.id); } });
        ids.forEach(function (id) { if (!got[id]) delete _thumbAsked[id]; });   // réessayé plus tard si absent
        _scanThumbs();
      })
      .catch(function () { ids.forEach(function (id) { delete _thumbAsked[id]; }); });
  }
  function _wantThumb(id) {
    if (!id || _thumbCache[id] || _thumbAsked[id]) return;
    _thumbWanted[id] = 1;
    if (!_thumbTimer) _thumbTimer = setTimeout(_flushThumbs, 120);
  }
  // Rattrape les vignettes dont l'image n'a pas été appliquée (icône créée avant l'arrivée de la réponse)
  var _scanTimer = null, _scanTries = 0;
  function _scanThumbs() {
    var els = document.querySelectorAll('.osm-thumb-img:not([data-ok])');
    var missing = 0;
    for (var i = 0; i < els.length; i++) {
      var id = els[i].getAttribute('data-pid');
      if (_thumbCache[id]) { _applyThumb(id); } else { missing++; _wantThumb(id); }
    }
    if (missing && _scanTries < 8) { _scanTries++; clearTimeout(_scanTimer); _scanTimer = setTimeout(_scanThumbs, 600); }
    else if (!missing) _scanTries = 0;
  }
  function _thumbIcon(id, count, size) {
    _wantThumb(id);
    var u = _thumbCache[id];
    var html = '<div class="osm-thumb"><div class="osm-thumb-img" data-pid="' + id + '"' +
               (u ? ' data-ok="1" style="background-image:url(&quot;' + _cssUrl(u) + '&quot;)"' : '') + '></div>' +
               (count > 1 ? '<span class="osm-thumb-n">' + count + '</span>' : '') + '</div>';
    return L.divIcon({ html: html, className: 'osm-thumb-wrap', iconSize: [size, size + 9], iconAnchor: [size / 2, size + 9] });
  }
  // Icône d'une photo isolée : créée seulement quand le marqueur est réellement affiché (évite de réclamer 16 000 miniatures)
  var _LazyThumb = null;
  function _lazyThumbIcon(id) {
    if (!_LazyThumb) {
      _LazyThumb = L.Icon.extend({
        options: { iconSize: [46, 55], iconAnchor: [23, 55], popupAnchor: [0, -52] },
        createIcon: function (old) { return _thumbIcon(this.options.pid, 1, 46).createIcon(old); },
        createShadow: function () { return null; }
      });
    }
    return new _LazyThumb({ pid: id });
  }
  function _thumbClusterIcon(cluster) {
    var n = cluster.getChildCount();
    var kids = cluster.getAllChildMarkers();
    var rep = kids.length && kids[0]._osmPhoto ? kids[0]._osmPhoto.id : 0;
    var size = n >= 1000 ? 92 : (n >= 100 ? 78 : (n >= 10 ? 66 : 56));
    return _thumbIcon(rep, n, size);
  }
  function _toggleThumbs() {
    thumbsMode = !thumbsMode;
    try { window.localStorage.setItem('osmme_thumbs', thumbsMode ? '1' : '0'); } catch (e) {}
    _syncThumbsButton();
    if (_lastPhotos) _renderMarkers(_lastPhotos);
  }
  function _syncThumbsButton() {
    var b = document.getElementById('osm-btn-thumbs');
    if (!b) return;
    b.classList.toggle('osm-btn-active', thumbsMode);
    b.setAttribute('aria-pressed', thumbsMode ? 'true' : 'false');
  }

  function _renderMarkers(photos) {
    if (!clusterGroup) return;
    _lastPhotos = photos;
    clusterGroup.clearLayers();
    if (!photos || !photos.length) { _updateStats(0); return; }

    var token = ++_renderToken;   // invalide les chunks d'un rendu précédent
    var CHUNK = photos.length > 5000 ? 500 : (photos.length > 1000 ? 200 : 100);
    var idx = 0;

    function addChunk() {
      if (token !== _renderToken) return;  // rendu annulé
      var batch = [];
      photos.slice(idx, idx + CHUNK).forEach(function (p) {
        var marker = L.marker([p.latitude, p.longitude], thumbsMode ? { icon: _lazyThumbIcon(p.id) } : undefined);
        marker._osmPhoto = p;
        marker.on('click', function () {
          var self = this;
          var photo = self._osmPhoto;
          _highlightPanel(photo.id);
          if (self._popupBound) { self.openPopup(); return; }
          var photoUrl = window.OSM_PHOTO_URL;
          if (photoUrl && !photo.name) {
            self.bindPopup('<div style="padding:8px;color:#888;font-size:12px;">Chargement…</div>', { maxWidth: 260 }).openPopup();
            fetch(photoUrl + '?id=' + photo.id, { credentials: 'same-origin' })
              .then(function(r) { return r.json(); })
              .then(function(data) {
                photo.name          = data.name;
                photo.date          = data.date;
                photo.album_name    = data.album_name;
                photo.thumbnail_url = data.thumbnail_url;
                photo.page_url      = data.page_url;
                self._popupBound = true;
                self.setPopupContent(_buildPopup(photo));
              })
              .catch(function() {
                self.setPopupContent('<div style="padding:8px;">Photo #' + photo.id + '</div>');
              });
          } else {
            self.bindPopup(_buildPopup(photo), { maxWidth: 260 }).openPopup();
            self._popupBound = true;
          }
        });
        batch.push(marker);
      });
      clusterGroup.addLayers(batch);
      idx += CHUNK;
      if (idx < photos.length) { requestAnimationFrame(addChunk); return; }
      // Fin du rendu — pas de fitBounds ici (déjà fait dans init)
      _updateStats(photos.length);
      _updatePanelFromBounds();
    }
    requestAnimationFrame(addChunk);
  }

  // Reconstruit l'URL page depuis l'id si absente du payload JSON (payload minimal)
  function _getPageUrl(p) {
    if (p.page_url) return p.page_url;
    return (window.OSM_ROOT || '') + 'picture.php?/' + p.id;
  }

  function _buildPopup(p) {
    var pageUrl = _getPageUrl(p);
    var html = '<div style="font-size:13px;max-width:230px;">';
    if (p.thumbnail_url) {
      html += '<a href="' + pageUrl + '" target="_blank" rel="noopener">'
            + '<img src="' + p.thumbnail_url + '" '
            + 'style="width:100%;max-height:130px;object-fit:cover;border-radius:4px;margin-bottom:6px;display:block;" '
            + 'onerror="this.style.display=\'none\'">'
            + '</a>';
    }
    html += '<a href="' + pageUrl + '" target="_blank" rel="noopener" style="font-weight:700;color:#1a73e8;text-decoration:none;font-size:14px;">'
          + _esc(p.name) + '</a>';
    if (p.album_name) html += '<div style="color:#555;margin-top:3px;font-size:12px;">&#128193; ' + _esc(p.album_name) + '</div>';
    if (p.date)       html += '<div style="color:#888;font-size:11px;margin-top:2px;">&#128197; ' + p.date + '</div>';
    html += '</div>';
    return html;
  }

  var _panelLoadTimer = null;

  function _updatePanelFromBounds() {
    if (!map) return;
    var bounds = map.getBounds();

    // Filtrer strictement les photos dans les bounds actuelles
    inViewPhotos = visiblePhotos.filter(function (p) {
      var lat = parseFloat(p.latitude);
      var lng = parseFloat(p.longitude);
      if (isNaN(lat) || isNaN(lng)) return false;
      return bounds.contains([lat, lng]);
    });
    _updateStats(inViewPhotos.length, visiblePhotos.length);

    // Panneau : 50 photos max, triées par distance au centre de la vue
    var MAX_PANEL = 200;
    var center = map.getCenter();
    var toShow = inViewPhotos.slice().sort(function(a, b) {
      var da = Math.pow(parseFloat(a.latitude) - center.lat, 2)
             + Math.pow(parseFloat(a.longitude) - center.lng, 2);
      var db = Math.pow(parseFloat(b.latitude) - center.lat, 2)
             + Math.pow(parseFloat(b.longitude) - center.lng, 2);
      return da - db;
    }).slice(0, MAX_PANEL);

    // Si aucune photo dans la vue, afficher un message
    if (!toShow.length) {
      var panelList = document.getElementById('osm-panel-list');
      if (panelList) panelList.innerHTML = '<div style="padding:16px;color:#888;font-size:12px;font-style:italic">Aucune photo dans cette zone.<br>Essayez de d\u00e9zoomer ou de changer l\u2019album.</div>';
      var countEl0 = document.getElementById('osm-panel-count');
      if (countEl0) countEl0.textContent = '0 photo visible';
      return;
    }

    // Si les photos ont déjà leurs détails (nom, url), afficher directement
    var needsLoad = toShow.filter(function(p) { return !p.name; });
    if (!needsLoad.length) {
      _renderPanel(toShow);
      return;
    }

    // Charger les détails manquants en batch, avec debounce 300ms
    clearTimeout(_panelLoadTimer);
    _panelLoadTimer = setTimeout(function() {
      var photoUrl = window.OSM_PHOTO_URL;
      if (!photoUrl) { _renderPanel(toShow); return; }

      var ids = needsLoad.map(function(p) { return p.id; }).join(',');
      fetch(photoUrl + '?ids=' + ids, { credentials: 'same-origin' })
        .then(function(r) { return r.json(); })
        .then(function(details) {
          // Mettre en cache les détails dans les objets photo
          var map_detail = {};
          details.forEach(function(d) { map_detail[d.id] = d; });
          toShow.forEach(function(p) {
            if (map_detail[p.id]) {
              p.name          = map_detail[p.id].name;
              p.date          = map_detail[p.id].date;
              p.album_name    = map_detail[p.id].album_name;
              p.thumbnail_url = map_detail[p.id].thumbnail_url;
              p.page_url      = map_detail[p.id].page_url;
            }
          });
          _renderPanel(toShow);
        })
        .catch(function() { _renderPanel(toShow); });
    }, 300);
  }

  function _renderPanel(photos) {
    var list    = document.getElementById('osm-panel-list');
    var countEl = document.getElementById('osm-panel-count');
    if (!list) return;

    if (countEl) {
      var total = inViewPhotos ? inViewPhotos.length : photos.length;
      var shown = photos.length;
      if (total > shown) {
        countEl.textContent = shown + ' / ' + total + ' photos — triées par distance';
      } else {
        countEl.textContent = shown + ' photo' + (shown > 1 ? 's' : '') + ' visibles';
      }
    }

    if (!photos.length) {
      list.innerHTML = '<p style="padding:12px;color:#888;font-size:13px;">Aucune photo dans cette zone.</p>';
      return;
    }

    var html = '';
    photos.forEach(function (p) {
      html += '<div class="osm-panel-item" id="osm-pi-' + p.id + '"'
            + ' data-lat="' + p.latitude + '" data-lon="' + p.longitude + '">';

      // Miniature — lien natif sans target="_blank" (compatible Safari localhost)
      html += '<a href="' + p.page_url + '" class="osm-pi-thumb-link" target="_blank" rel="noopener">';
      html += '<div class="osm-pi-thumb">';
      if (p.thumbnail_url) {
        html += '<img src="' + p.thumbnail_url + '" alt="" loading="lazy"'
              + ' onerror="this.parentNode.innerHTML=\'&#128247;\'">';
      } else {
        html += '<span>&#128247;</span>';
      }
      html += '</div></a>';

      // Infos — lien natif
      html += '<a href="' + p.page_url + '" class="osm-pi-info" target="_blank" rel="noopener">';
      html += '<span class="osm-pi-name">' + _esc(p.name) + '</span>';
      if (p.album_name) html += '<span class="osm-pi-album">&#128193; ' + _esc(p.album_name) + '</span>';
      if (p.date)       html += '<span class="osm-pi-date">&#128197; ' + p.date + '</span>';
      html += '</a>';

      html += '</div>';
    });

    list.innerHTML = html;

    // Clic sur le div wrapper (hors lien) → centre la carte
    list.querySelectorAll('.osm-panel-item').forEach(function (item) {
      var lat = parseFloat(item.dataset.lat);
      var lon = parseFloat(item.dataset.lon);
      item.addEventListener('click', function (e) {
        var node = e.target;
        while (node && node !== item) {
          if (node.tagName === 'A') return; // laisser le lien fonctionner
          node = node.parentNode;
        }
        map.setView([lat, lon], 16);
        clusterGroup.eachLayer(function (layer) {
          if (layer.getLatLng &&
              Math.abs(layer.getLatLng().lat - lat) < 0.0001 &&
              Math.abs(layer.getLatLng().lng - lon) < 0.0001) {
            layer.openPopup();
          }
        });
      });
    });
  }

  function _highlightPanel(photoId) {
    var item = document.getElementById('osm-pi-' + photoId);
    if (!item) return;
    var prev = document.querySelector('.osm-panel-item.active');
    if (prev) prev.classList.remove('active');
    item.classList.add('active');
    if (panelOpen) item.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  // Sélecteur « Lieux favoris » à côté du choix d'album : centre la carte sur le lieu
  function _addPlacesSelect() {
    var list = window.OSM_FAV_PLACES;
    if (!list || !list.length || document.getElementById('osm-places-filter')) return;
    var wrap = document.createElement('span');
    wrap.className = 'osm-fav-places';
    wrap.style.cssText = 'white-space:nowrap;';
    var lab = document.createElement('label');
    lab.setAttribute('for', 'osm-places-filter');
    lab.innerHTML = '&nbsp;&#11088; Lieux favoris&nbsp;:&nbsp;';
    var sel = document.createElement('select');
    sel.id = 'osm-places-filter';
    sel.style.maxWidth = '200px';
    var o0 = document.createElement('option'); o0.value = ''; o0.textContent = '\u2014 Choisir \u2014'; sel.appendChild(o0);
    list.forEach(function (p, i) { var o = document.createElement('option'); o.value = i; o.textContent = p.name; sel.appendChild(o); });
    sel.addEventListener('change', function () {
      var p = list[this.value];
      if (p && map) { map.setView([p.lat, p.lon], 14); }
    });
    wrap.appendChild(lab); wrap.appendChild(sel);
    var album = document.getElementById('osm-album-filter');
    if (album && album.parentNode) { album.parentNode.insertBefore(wrap, album.nextSibling); return; }
    var anchor = document.getElementById('osm-btn-panel');
    if (anchor && anchor.parentNode) { anchor.parentNode.insertBefore(wrap, anchor); }
  }

  function _bindControls() {
    _addPlacesSelect();
    _addSlideshowButton();
    var sel = document.getElementById('osm-album-filter');
    if (sel) {
      sel.addEventListener('change', function () {
        var albumId = parseInt(this.value, 10) || null;
        var pointsBase = window.OSM_POINTS_URL;

        if (!pointsBase) {
          // Fallback page galerie : filtrage local sur album_id
          visiblePhotos = albumId
            ? allPhotos.filter(function (p) { return p.album_id === albumId; })
            : allPhotos.slice();
          map.off('moveend zoomend', _updatePanelFromBounds);
          _renderMarkers(visiblePhotos);
          setTimeout(function() {
            map.on('moveend zoomend', _updatePanelFromBounds);
            _updatePanelFromBounds();
          }, 200);
          return;
        }

        // Rechargement via API avec filtre cat_id
        var url = albumId ? pointsBase + '?cat_id=' + albumId : pointsBase;
        _showLoading(true);
        fetch(url, { credentials: 'same-origin' })
          .then(function(r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.text();
          })
          .then(function(text) {
            var trimmed = text.trim();
            if (!trimmed || trimmed[0] !== '[') throw new Error('Non-JSON');
            return JSON.parse(trimmed);
          })
          .then(function(data) {
            visiblePhotos = data.map(function(p) {
              return { id: p[0], latitude: p[1], longitude: p[2] };
            });
            // Recentrer sur la sélection
            var bounds = _computeBounds(visiblePhotos);
            if (bounds) {
              try {
                var b = L.latLngBounds(bounds[0], bounds[1]);
                if (b.isValid()) map.fitBounds(b.pad(0.1));
              } catch(e) {}
            }
            map.off('moveend zoomend', _updatePanelFromBounds);
            _renderMarkers(visiblePhotos);
            setTimeout(function() {
              map.on('moveend zoomend', _updatePanelFromBounds);
              _updatePanelFromBounds();
            }, 200);
            _showLoading(false);
          })
          .catch(function(err) {
            console.error('OSM Map: erreur filtre album', err);
            _showLoading(false);
          });
      });
    }

    var input = document.getElementById('osm-geocoder');
    var drop  = document.getElementById('osm-geocoder-results');
    if (input && drop) {
      input.addEventListener('input', function () {
        clearTimeout(geocodeTimer);
        var q = this.value.trim();
        if (q.length < 3) { drop.style.display = 'none'; return; }
        geocodeTimer = setTimeout(function () { _geocode(q, drop, input); }, 600);
      });
      document.addEventListener('click', function (e) {
        if (!input.contains(e.target) && !drop.contains(e.target)) drop.style.display = 'none';
      });
    }

    var btnFit = document.getElementById('osm-btn-fit');
    if (btnFit) {
      btnFit.addEventListener('click', function () {
        try { var b = clusterGroup.getBounds(); if (b.isValid()) map.fitBounds(b.pad(0.1)); } catch(e) {}
      });
    }

    var btnPanel = document.getElementById('osm-btn-panel');
    var btnClose = document.getElementById('osm-panel-close');
    var panel    = document.getElementById('osm-panel');
    function togglePanel() {
      panelOpen = !panelOpen;
      if (panel)    panel.classList.toggle('osm-panel-open', panelOpen);
      if (btnPanel) btnPanel.classList.toggle('active', panelOpen);
      setTimeout(function () { if (map) map.invalidateSize(); }, 300);
    }
    if (btnPanel) btnPanel.addEventListener('click', togglePanel);
    if (btnClose) btnClose.addEventListener('click', togglePanel);

    // Bouton créer album
    var btnAlbum = document.getElementById('osm-btn-album');
    if (btnAlbum && !window.OSM_IS_ADMIN) { btnAlbum.style.display = 'none'; }
    if (btnAlbum && window.OSM_IS_ADMIN) {
      btnAlbum.addEventListener('click', function () {
        if (!inViewPhotos || inViewPhotos.length === 0) {
          _showToast('Aucune photo visible sur la carte.', 'info');
          return;
        }
        _createAlbumModal();
      });
    }
  }

  function _geocode(query, drop, input) {
    fetch('https://nominatim.openstreetmap.org/search?format=json&limit=6&q=' + encodeURIComponent(query), {
      headers: { 'Accept-Language': 'fr' }
    })
    .then(function (r) { return r.json(); })
    .then(function (results) {
      if (!results || !results.length) {
        drop.innerHTML = '<div class="osm-geo-item osm-geo-empty">Aucun résultat</div>';
        drop.style.display = 'block'; return;
      }
      drop.innerHTML = results.map(function (r) {
        return '<div class="osm-geo-item" data-lat="' + r.lat + '" data-lon="' + r.lon + '">'
             + _esc(r.display_name) + '</div>';
      }).join('');
      drop.style.display = 'block';
      drop.querySelectorAll('.osm-geo-item[data-lat]').forEach(function (item) {
        item.addEventListener('click', function () {
          var lat = parseFloat(this.dataset.lat);
          var lon = parseFloat(this.dataset.lon);
          drop.style.display = 'none';
          input.value = this.textContent;
          map.setView([lat, lon], 12);
          // Forcer la mise à jour du panneau après que la vue soit stabilisée
          setTimeout(function() { _updatePanelFromBounds(); }, 400);
        });
      });
    })
    .catch(function () {
      drop.innerHTML = '<div class="osm-geo-item osm-geo-empty">Erreur géocodage</div>';
      drop.style.display = 'block';
    });
  }

  function _updateStats(visible, total) {
    var v = document.getElementById('osm-count-visible');
    var t = document.getElementById('osm-count-total');
    if (v) v.textContent = visible;
    if (t && total !== undefined) t.textContent = total;
  }

  function _esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }


  // ── Création d'album ───────────────────────────────────────────────────────
  function _createAlbumModal() {
    // Supprimer modal existante
    var old = document.getElementById('osm-album-modal');
    if (old) old.remove();

    var today = new Date();
    var dateStr = today.getFullYear() + '-'
      + String(today.getMonth()+1).padStart(2,'0') + '-'
      + String(today.getDate()).padStart(2,'0');
    var defaultName = 'Carte ' + dateStr + ' (' + inViewPhotos.length + ' photos)';

    var modal = document.createElement('div');
    modal.id = 'osm-album-modal';
    modal.innerHTML = [
      '<div id="osm-album-overlay"></div>',
      '<div id="osm-album-dialog">',
      '  <h3>&#128194; Créer un album</h3>',
      '  <p id="osm-album-desc"><strong>' + inViewPhotos.length + '</strong> photos visibles seront ajoutées.</p>',
      '  <label for="osm-album-name">Nom de l&#39;album</label>',
      '  <input type="text" id="osm-album-name" value="' + defaultName + '" />',
      '  <div id="osm-album-progress" style="display:none;">',
      '    <div id="osm-album-bar"><div id="osm-album-bar-inner"></div></div>',
      '    <span id="osm-album-status">Création en cours…</span>',
      '  </div>',
      '  <div id="osm-album-actions">',
      '    <button id="osm-album-cancel">Annuler</button>',
      '    <button id="osm-album-confirm">&#10003; Créer</button>',
      '  </div>',
      '</div>'
    ].join('');
    document.body.appendChild(modal);

    document.getElementById('osm-album-overlay').addEventListener('click', function () { modal.remove(); });
    document.getElementById('osm-album-cancel').addEventListener('click', function () { modal.remove(); });
    document.getElementById('osm-album-confirm').addEventListener('click', function () {
      var name = document.getElementById('osm-album-name').value.trim();
      if (!name) { document.getElementById('osm-album-name').focus(); return; }
      _doCreateAlbum(name, modal);
    });
    // Focus sur le champ
    setTimeout(function () {
      var inp = document.getElementById('osm-album-name');
      if (inp) { inp.focus(); inp.select(); }
    }, 50);
  }

  // Parse réponse Piwigo : JSON ou XML selon la version
  function _parseResponse(text) {
    text = (text || '').trim();
    if (text.charAt(0) === '{') {
      var d = JSON.parse(text);
      if (d.stat !== 'ok') throw new Error(d.message || 'Erreur API');
      return d.result;
    }
    // Fallback XML
    var parser = new DOMParser();
    var xml    = parser.parseFromString(text, 'text/xml');
    var rsp    = xml.querySelector('rsp');
    if (!rsp || rsp.getAttribute('stat') !== 'ok') {
      var err = xml.querySelector('err');
      throw new Error(err ? err.getAttribute('msg') : 'Erreur API (XML)');
    }
    var result = {};
    Array.from(rsp.children).forEach(function (el) {
      result[el.tagName] = el.textContent.trim();
    });
    return result;
  }

  function _doCreateAlbum(name, modal) {
    var actions  = document.getElementById('osm-album-actions');
    var progress = document.getElementById('osm-album-progress');
    var status   = document.getElementById('osm-album-status');
    var barInner = document.getElementById('osm-album-bar-inner');
    if (actions)  actions.style.display  = 'none';
    if (progress) progress.style.display = 'block';

    function setStatus(msg, pct) {
      if (status)   status.textContent     = msg;
      if (barInner) barInner.style.width   = (pct || 0) + '%';
    }

    // Étape 1 : créer la catégorie via ws.php
    setStatus('Création de l&#39;album…', 10);
    var params1 = new URLSearchParams();
    params1.append('method', 'pwg.categories.add');
    params1.append('format', 'json');
    params1.append('name',   name);

    fetch(apiUrl, { method: 'POST', body: params1 })
    .then(function (r) { return r.text(); })
    .then(function (text) {
      var data;
      var result = _parseResponse(text);

      var catId = result.id;
      if (!catId) throw new Error('ID album non reçu dans la réponse');
      var photoIds = inViewPhotos.map(function (p) { return p.id; });

      setStatus('Ajout de ' + photoIds.length + ' photos…', 30);

      // Étape 2 : associer les photos à la catégorie par lots de 100
      var BATCH = 100;
      var batches = [];
      for (var i = 0; i < photoIds.length; i += BATCH) {
        batches.push(photoIds.slice(i, i + BATCH));
      }

      var done = 0;
      function nextBatch() {
        if (done >= batches.length) {
          setStatus('Album créé avec succès !', 100);
          setTimeout(function () {
            modal.remove();
            _showToast('Album "' + name + '" créé avec ' + photoIds.length + ' photos !', 'success');
          }, 200);
          return;
        }
        var batch  = batches[done];
        var params2 = new URLSearchParams();
        params2.append('method',       'pwg.images.addSimple');
        params2.append('format',       'json');
        params2.append('category',     catId);
        batch.forEach(function (id) { params2.append('image_id[]', id); });

        // pwg.images.addSimple ne supporte pas le batch — utiliser setInfo pour chaque photo
        // On utilise pwg.images.setInfo avec categories
        var params3 = new URLSearchParams();
        params3.append('method',  'pwg.images.setInfo');
        params3.append('format',  'json');
        params3.append('image_id', batch[0]);
        params3.append('categories', catId);

        // Utiliser l'API batch native : pwg.images.addToAlbum si disponible
        // Sinon : appel séquentiel pwg.images.setInfo
        var params4 = new URLSearchParams();
        params4.append('method',      'pwg.categories.setInfo');
        params4.append('format',      'json');
        params4.append('category_id', catId);

        // La vraie méthode pour associer plusieurs images : IMAGE_CATEGORY_TABLE direct
        // Via API : pwg.images.add ne convient pas. On utilise la méthode la plus compatible :
        // POST sur pwg.images.setInfo image par image est trop lent
        // MEILLEURE approche : pwg.images.addToAlbum (Piwigo 2.7+)
        var paramsAdd = new URLSearchParams();
        paramsAdd.append('method',      'pwg.images.addToAlbum');
        paramsAdd.append('format',      'json');
        paramsAdd.append('category_id', catId);
        batch.forEach(function (id) { paramsAdd.append('image_id[]', id); });

        fetch(apiUrl, { method: 'POST', body: paramsAdd })
        .then(function (r) { return r.text(); })
        .then(function (text) {
          var res;
          try { res = JSON.parse(text); } catch(e) { res = {}; }
          // Si méthode inconnue, fallback sur setInfo individuel
          if (!res || res.stat !== 'ok') {
            return _addPhotosOneByOne(batch, catId, done, batches.length, setStatus, nextBatch);
          }
          done++;
          setStatus('Ajout… ' + Math.min(done * BATCH, photoIds.length) + '/' + photoIds.length, 30 + (done/batches.length)*65);
          nextBatch();
        })
        .catch(function () {
          _addPhotosOneByOne(batch, catId, done, batches.length, setStatus, nextBatch);
        });
        done++;
      }
      nextBatch();
    })
    .catch(function (err) {
      setStatus('Erreur : ' + err.message, 0);
      if (actions) actions.style.display = 'flex';
    });
  }

  // Fallback : ajouter les photos une par une via pwg.images.setInfo
  function _addPhotosOneByOne(batch, catId, batchIdx, totalBatches, setStatus, onDone) {
    var idx = 0;
    function next() {
      if (idx >= batch.length) { onDone(); return; }
      var params = new URLSearchParams();
      params.append('method',      'pwg.images.setInfo');
      params.append('format',      'json');
      params.append('image_id',    batch[idx]);
      params.append('categories',  catId);
      params.append('multiple_value_mode', 'append');
      fetch(apiUrl, { method: 'POST', body: params })
      .then(function () { idx++; next(); })
      .catch(function () { idx++; next(); });
    }
    next();
  }

  function _showToast(msg, type) {
    var toast = document.createElement('div');
    toast.className = 'osm-toast osm-toast-' + (type || 'info');
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(function () {
      toast.style.opacity = '0';
      setTimeout(function () { toast.remove(); }, 400);
    }, 3500);
  }

  return { init: init };
})();
